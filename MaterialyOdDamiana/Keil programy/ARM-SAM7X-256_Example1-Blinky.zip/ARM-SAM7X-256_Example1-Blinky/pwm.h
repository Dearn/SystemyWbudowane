
void InitPWM(void);
void SetPWMValue(unsigned int val);
