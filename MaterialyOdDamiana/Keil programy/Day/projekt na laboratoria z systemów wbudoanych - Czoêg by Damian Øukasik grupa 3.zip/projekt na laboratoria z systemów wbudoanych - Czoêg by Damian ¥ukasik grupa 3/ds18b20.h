#ifndef __DS18B20_H__
#define __DS18B20_H__

void ds18b20ConvertT(void);
short ds18b20ReadTempNoRom(void);
char ds18b20Init(void);


#endif

